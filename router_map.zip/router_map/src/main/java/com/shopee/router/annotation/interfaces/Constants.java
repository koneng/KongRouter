package com.shopee.router.annotation.interfaces;

public interface Constants {

    String ROUTER_MAP_NAME = "RouterMap";
    String ROUTER_MAP_PACKAGE_NAME = "com.shopee.router";
    String KEY_MODULE_NAME = "moduleName";
}
